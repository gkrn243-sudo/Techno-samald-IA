# Techno Samald 🤖

Assistant IA moderne et créatif construit sur Base44.

## Stack technique
- ⚛️  React + Vite
- 🎨 Tailwind CSS + shadcn/ui
- 🧠 LLM : GPT-4o mini (normal) / Claude Sonnet 4.6 (deep think)
- 🗄️  Base de données : Base44 Entities (Conversation)
- 🔊 Voix : Web Speech API (fr-FR)
- 🖼️  Images : DALL-E via Base44 GenerateImage
- 🌐 Recherche web : Base44 InvokeLLM avec add_context_from_internet

## Structure des fichiers
```
TS/
├── pages/
│   └── Chat.jsx                   ← Cerveau principal
├── components/gia/
│   ├── GIALogo.jsx
│   ├── ConversationSidebar.jsx
│   ├── MessageBubble.jsx
│   ├── ChatInput.jsx
│   ├── ModeSelector.jsx
│   ├── TypingIndicator.jsx
│   ├── ChatHistory.jsx
│   └── QuizCard.jsx
├── entities/
│   └── Conversation.json          ← Schéma BDD
└── README.md
```

## Commande secrète
Tapez `€$ franc` dans le chat pour accéder à ce code source.
