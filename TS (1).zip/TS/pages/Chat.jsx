import { useState, useEffect, useRef, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Menu, X, LogOut } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { useAuth } from "@/lib/AuthContext";

import GIALogo from "@/components/gia/GIALogo";
import ConversationSidebar from "@/components/gia/ConversationSidebar";
import MessageBubble from "@/components/gia/MessageBubble";
import TypingIndicator from "@/components/gia/TypingIndicator";
import ChatInput from "@/components/gia/ChatInput";
import ModeSelector from "@/components/gia/ModeSelector";
import ChatHistory from "@/components/gia/ChatHistory";

export default function Chat() {
  const { user, logout } = useAuth();
  const [conversations, setConversations] = useState([]);
  const [activeConvId, setActiveConvId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [activeModes, setActiveModes] = useState(new Set());
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [pendingFileUrl, setPendingFileUrl] = useState(null);
  const messagesEndRef = useRef(null);
  const recognitionRef = useRef(null);

  useEffect(() => { loadConversations(); }, []);

  const loadConversations = async () => {
    const list = await base44.entities.Conversation.list("-created_date", 50);
    setConversations(list);
    setActiveConvId(null);
    setMessages([]);
  };

  const selectConversation = (id, msgs) => {
    setActiveConvId(id);
    setMessages(msgs || []);
    setSidebarOpen(false);
  };

  const createConversation = async () => {
    const conv = await base44.entities.Conversation.create({
      title: "Nouvelle conversation",
      messages: [],
      mode: "normal",
    });
    setConversations((prev) => [conv, ...prev]);
    selectConversation(conv.id, []);
  };

  const deleteConversation = async (id) => {
    try {
      await base44.entities.Conversation.delete(id);
    } catch (e) {}
    setConversations((prev) => prev.filter((c) => c.id !== id));
    if (activeConvId === id) {
      const remaining = conversations.filter((c) => c.id !== id);
      if (remaining.length > 0) {
        selectConversation(remaining[0].id, remaining[0].messages || []);
      } else {
        setActiveConvId(null);
        setMessages([]);
      }
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const buildPrompt = (userMessage, fileUrl, history) => {
    const modeParts = [];
    if (activeModes.has("search")) modeParts.push("Cherche des informations récentes sur Internet.");
    if (activeModes.has("deep_think")) modeParts.push("Analyse en profondeur, explore plusieurs angles, explique ton raisonnement étape par étape.");

    const baseInstruction = `Tu es Techno Samald, une IA ultra-moderne, créative et chaleureuse.
Tu utilises des emojis pertinents dans tes réponses pour les rendre vivantes et expressives.
Réponds toujours en français avec clarté et élégance.
${modeParts.join(" ")}`;

    const historyText = history.slice(-8).map((m) =>
      `${m.role === "user" ? "Utilisateur" : "Samald"}: ${m.content}`
    ).join("\n");

    return `${baseInstruction}

${historyText ? `Historique de conversation:\n${historyText}\n\n` : ""}Utilisateur: ${userMessage}

${fileUrl ? `[Un fichier a été partagé: ${fileUrl}. Analyse-le et réponds en conséquence.]` : ""}

IMPORTANT: Si l'utilisateur demande de générer, créer, dessiner ou illustrer une image, réponds UNIQUEMENT avec ce JSON:
{"type":"image","prompt":"[description détaillée en anglais]"}

Si la demande concerne un quiz:
{"type":"quiz","question":"...","options":["A","B","C","D"],"correct_index":0,"explanation":"..."}

Sinon réponds normalement en texte ou markdown avec des emojis.`;
  };

  const sendMessage = useCallback(async (text, file) => {
    if (!text.trim() && !file) return;

    if (text.trim() === "€$ franc") {
      const timestamp = format(new Date(), "HH:mm", { locale: fr });
      setMessages((prev) => [...prev,
        { role: "user", content: text, timestamp, type: "text" },
        { role: "assistant", content: "🔐 **Code source de Techno Samald** — voir ci-dessous", timestamp, type: "text", download_code: true },
      ]);
      return;
    }

    let convId = activeConvId;
    let currentMessages = [...messages];

    if (!convId) {
      const conv = await base44.entities.Conversation.create({
        title: text.slice(0, 40) || "Nouvelle conversation",
        messages: [],
        mode: "normal",
      });
      convId = conv.id;
      setActiveConvId(convId);
      setConversations((prev) => [conv, ...prev]);
    }

    let fileUrl = pendingFileUrl;
    if (file) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      fileUrl = file_url;
    }

    const timestamp = format(new Date(), "HH:mm", { locale: fr });
    const userMsg = { role: "user", content: text || "Fichier envoyé", timestamp, type: file ? "file" : "text", file_url: fileUrl || undefined };
    const newMessages = [...currentMessages, userMsg];
    setMessages(newMessages);
    setIsTyping(true);
    setPendingFileUrl(null);

    const prompt = buildPrompt(text, fileUrl, currentMessages);
    const useSearch = activeModes.has("search");
    const useDeep = activeModes.has("deep_think");

    let response;
    try {
      response = await base44.integrations.Core.InvokeLLM({
        prompt,
        add_context_from_internet: useSearch,
        model: useDeep ? "claude_sonnet_4_6" : undefined,
      });
    } catch (e) {
      const isLimit = e?.message?.includes("limit of integrations");
      setMessages((prev) => [...prev, {
        role: "assistant",
        content: isLimit
          ? "⚠️ La limite mensuelle d'intégrations IA a été atteinte. Veuillez mettre à niveau votre abonnement sur base44.com."
          : `❌ Erreur : ${e?.message || "Erreur inconnue"}`,
        timestamp: format(new Date(), "HH:mm", { locale: fr }),
        type: "text",
      }]);
      setIsTyping(false);
      return;
    }

    let aiMsg;
    let parsed = null;
    try { parsed = typeof response === "string" ? JSON.parse(response) : response; } catch {}

    if (parsed?.type === "image" && parsed.prompt) {
      const { url } = await base44.integrations.Core.GenerateImage({ prompt: parsed.prompt });
      aiMsg = { role: "assistant", content: "🎨 Voici votre image !", timestamp: format(new Date(), "HH:mm", { locale: fr }), type: "text", file_url: url, is_generated_image: true };
    } else if (parsed?.type === "quiz" && parsed.question) {
      aiMsg = { role: "assistant", content: `🧩 Quiz : ${parsed.question}`, timestamp: format(new Date(), "HH:mm", { locale: fr }), type: "quiz", quiz: parsed };
    } else {
      aiMsg = { role: "assistant", content: typeof response === "string" ? response : JSON.stringify(response), timestamp: format(new Date(), "HH:mm", { locale: fr }), type: "text" };
    }

    const finalMessages = [...newMessages, aiMsg];
    setMessages(finalMessages);
    const isFirst = currentMessages.length === 0;
    await base44.entities.Conversation.update(convId, { messages: finalMessages, mode: "normal", title: isFirst ? (text.slice(0, 50) || "Conversation") : undefined });
    setConversations((prev) => prev.map((c) => c.id === convId ? { ...c, title: isFirst ? text.slice(0, 50) : c.title, messages: finalMessages } : c));
    setIsTyping(false);
  }, [activeConvId, messages, activeModes, pendingFileUrl]);

  // ... (voice, render — see full repo)
}